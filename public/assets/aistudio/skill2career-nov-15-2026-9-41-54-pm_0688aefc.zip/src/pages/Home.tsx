import { Link } from 'react-router-dom';
import {
  ClipboardCheck,
  FileText,
  Briefcase,
  TrendingUp,
  ArrowRight,
  CheckCircle2,
  UserPlus,
  Award,
  BookOpen,
  Compass
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/Button';
import { FeatureCard } from '../components/FeatureCard';
import { mockDashboardData } from '../data/mockDashboard';

const platformFeatures = [
  {
    title: 'Skill Assessment',
    description:
      'Measure job-ready competencies through structured evaluations tailored for business, operations, and graduate tracks.',
    items: [
      'Evaluate MS Excel skills',
      'Test analytical thinking',
      'Evaluate situation handling',
      'Assess management capabilities'
    ],
    icon: <ClipboardCheck className="h-5 w-5" aria-hidden="true" />,
    to: '/assessment',
    ctaLabel: 'Explore Skill Assessment'
  },
  {
    title: 'AI CV Builder',
    description:
      'Structure your academic projects and work history into crisp, recruiter-ready documents with tailored cover letters.',
    items: [
      'Create professional CVs',
      'Improve existing CVs',
      'Generate career objectives',
      'Prepare job-specific cover letters'
    ],
    icon: <FileText className="h-5 w-5" aria-hidden="true" />,
    to: '/resume-builder',
    ctaLabel: 'Preview Resume Builder'
  },
  {
    title: 'Career Opportunities',
    description:
      'Browse entry-level, internship, and graduate roles aligned with the capabilities you demonstrate.',
    items: [
      'Explore job opportunities',
      'Discover relevant vacancies',
      'Track job applications'
    ],
    icon: <Briefcase className="h-5 w-5" aria-hidden="true" />,
    to: '/jobs',
    ctaLabel: 'Browse Sample Jobs'
  },
  {
    title: 'Career Development',
    description:
      'Turn assessment feedback into focused preparation with clear skill-gap breakdowns and study guides.',
    items: [
      'Identify skill gaps',
      'Discover strengths and weaknesses',
      'Access recommended learning resources'
    ],
    icon: <TrendingUp className="h-5 w-5" aria-hidden="true" />,
    to: '/dashboard',
    ctaLabel: 'View Student Dashboard'
  }
];

const steps = [
  {
    number: '01',
    title: 'Create Your Account',
    description:
      'Set up your academic profile with your degree qualification, career goals, and contact preferences.',
    icon: UserPlus
  },
  {
    number: '02',
    title: 'Complete Skill Assessment',
    description:
      'Take the structured 20-minute evaluation across MS Excel, situation handling, analytical reasoning, and management.',
    icon: ClipboardCheck
  },
  {
    number: '03',
    title: 'Build Your Professional CV',
    description:
      'Choose from 10 clean templates, refine bullet points, and prepare tailored cover letters.',
    icon: FileText
  },
  {
    number: '04',
    title: 'Explore Career Opportunities',
    description:
      'Filter relevant internships and graduate positions while tracking skill-gap learning resources.',
    icon: Briefcase
  }
];

const whyItems = [
  {
    title: 'Skill-based career development',
    detail:
      'Move beyond generic guesswork with structured benchmarks across practical spreadsheet, analytical, and workplace skills.'
  },
  {
    title: 'Professional CV support',
    detail:
      'Present academic achievements and internships cleanly with 10 structured CV layouts and cover letter formatting.'
  },
  {
    title: 'Personalized career insights',
    detail:
      'Understand exactly where your strengths stand and which targeted learning modules raise your readiness.'
  },
  {
    title: 'Relevant job opportunities',
    detail:
      'Filter internships, graduate trainee programs, and entry-level roles by category, location, and experience.'
  },
  {
    title: 'Accessible for university students and graduates',
    detail:
      'Built from the ground up with free, open-access workflows tailored for students entering the workforce.'
  }
];

export function Home() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-white via-slate-50 to-slate-100/70 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
            <div className="lg:col-span-6 space-y-6">
              <p className="text-sm font-semibold text-[#1D4ED8] tracking-normal">
                Learn Your Skills. Discover Your Potential. Build Your Career.
              </p>

              <h1 className="text-4xl sm:text-5xl lg:text-[3.35rem] font-extrabold text-[#0B1936] tracking-tight leading-[1.1] text-balance">
                Your Career Starts With Knowing Your Skills.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
                Discover your strengths, evaluate your professional skills, build an impressive CV
                and find opportunities that match your potential.
              </p>

              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <Button to="/register" size="lg">
                  <span>Get Started Free</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Button>
                <Button to="/dashboard" variant="secondary" size="lg">
                  Explore Platform
                </Button>
              </div>

              <div className="pt-4 border-t border-slate-200/80 grid grid-cols-3 gap-4 max-w-lg text-xs sm:text-sm">
                <div>
                  <p className="font-bold text-[#0B1936] tabular-nums">20 Mins</p>
                  <p className="text-slate-500">Assessment Blueprint</p>
                </div>
                <div>
                  <p className="font-bold text-[#0B1936] tabular-nums">10 Templates</p>
                  <p className="text-slate-500">CV Layout Previews</p>
                </div>
                <div>
                  <p className="font-bold text-[#0B1936] tabular-nums">4 Core Tracks</p>
                  <p className="text-slate-500">Skill Evaluation</p>
                </div>
              </div>
            </div>

            {/* UI Component Dashboard Preview Illustration */}
            <div className="lg:col-span-6">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-lg overflow-hidden">
                <div className="bg-[#0B1936] text-white px-5 py-3.5 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2.5 text-sm font-semibold">
                    <Compass className="h-4 w-4 text-[#38BDF8]" aria-hidden="true" />
                    <span>Student Workspace Preview</span>
                  </div>
                  <span className="text-xs text-slate-300">Demonstration Data</span>
                </div>

                <div className="p-5 sm:p-6 space-y-5 bg-slate-50/70">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs font-medium text-slate-500">Career Score Preview</p>
                      <div className="mt-2 flex items-baseline gap-1.5 tabular-nums">
                        <span className="text-3xl font-extrabold text-[#0B1936]">
                          {mockDashboardData.careerScore.overall}
                        </span>
                        <span className="text-sm text-slate-400">/ 100</span>
                      </div>
                      <p className="mt-1 text-xs font-medium text-[#1D4ED8]">
                        {mockDashboardData.careerScore.readinessLabel}
                      </p>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs font-medium text-slate-500">CV Readiness</p>
                      <div className="mt-2 flex items-baseline gap-1.5 tabular-nums">
                        <span className="text-3xl font-extrabold text-[#0B1936]">
                          {mockDashboardData.cvStatus.percentage}%
                        </span>
                        <span className="text-xs text-slate-500">Draft Complete</span>
                      </div>
                      <div className="mt-2.5 h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-[#1D4ED8] to-[#0EA5E9]"
                          style={{ width: `${mockDashboardData.cvStatus.percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#0B1936]">Skill Assessment Summary</span>
                      <span className="text-slate-500">Sample Breakdown</span>
                    </div>
                    <div className="space-y-2.5">
                      {mockDashboardData.skillSummary.map((skill) => (
                        <div key={skill.id} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-medium text-slate-700">{skill.name}</span>
                            <span className="font-mono font-medium text-[#0B1936] tabular-nums">
                              {skill.score}%
                            </span>
                          </div>
                          <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-[#1D4ED8] via-[#2563EB] to-[#0EA5E9]"
                              style={{ width: `${skill.score}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="text-xs text-slate-600">
                      <span className="font-semibold text-[#0B1936]">3 Recommended Roles</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>Data &amp; Management Tracks</span>
                    </div>
                    <Link
                      to="/dashboard"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1D4ED8] hover:text-[#0B1936] transition-colors"
                    >
                      <span>Open Interactive Preview</span>
                      <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Features */}
      <section id="features" className="py-16 sm:py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <p className="text-sm font-semibold text-[#1D4ED8] mb-2">Platform Capabilities</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0B1936] tracking-tight text-balance">
              Four integrated pillars for career readiness
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              Every module in Skill2Career connects directly to the next — turning raw skill
              measurements into stronger CVs and focused job discovery.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {platformFeatures.map((feature) => (
              <FeatureCard
                key={feature.title}
                title={feature.title}
                description={feature.description}
                items={feature.items}
                icon={feature.icon}
                to={feature.to}
                ctaLabel={feature.ctaLabel}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl">
              <p className="text-sm font-semibold text-[#1D4ED8] mb-2">How It Works</p>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#0B1936] tracking-tight text-balance">
                A clear four-step path from student to candidate
              </h2>
            </div>
            <Button to="/how-it-works" variant="secondary" size="md">
              <span>View Detailed Walkthrough</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-5">
                      <span className="font-mono text-sm font-semibold text-[#1D4ED8] tabular-nums">
                        Step {step.number}
                      </span>
                      <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-[#0B1936]">
                        <Icon className="h-4 w-4" aria-hidden="true" />
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-[#0B1936] mb-2">{step.title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Skill2Career */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            <div className="lg:col-span-5 bg-[#0B1936] text-white rounded-2xl p-8 sm:p-10 space-y-6">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-white/10 text-[#38BDF8]">
                <Award className="h-5 w-5" aria-hidden="true" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-balance">
                Why Skill2Career
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                Graduating with a degree is only half the story. Employers look for verified
                spreadsheet fluency, analytical clarity, and structured communication. Skill2Career
                bridges that gap early.
              </p>
              <div className="pt-2 flex flex-wrap gap-3">
                <Button to="/register" size="md">
                  Get Started Free
                </Button>
                <Button
                  to="/assessment"
                  variant="ghost"
                  size="md"
                  className="text-white hover:bg-white/10 hover:text-white"
                >
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span>Preview Assessment</span>
                </Button>
              </div>
            </div>

            <div className="lg:col-span-7 divide-y divide-slate-200 border border-slate-200 rounded-2xl bg-white">
              {whyItems.map((item) => (
                <div key={item.title} className="p-5 sm:p-6 flex items-start gap-4">
                  <CheckCircle2
                    className="h-5 w-5 text-[#1D4ED8] shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <div>
                    <h3 className="text-base font-bold text-[#0B1936]">{item.title}</h3>
                    <p className="text-sm text-slate-600 mt-1 leading-relaxed">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
