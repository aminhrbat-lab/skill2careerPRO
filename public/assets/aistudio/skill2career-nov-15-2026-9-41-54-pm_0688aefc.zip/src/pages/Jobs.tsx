import { useMemo, useState } from 'react';
import {
  Search,
  Building2,
  RotateCcw,
  Info,
  X,
  MapPin,
  Briefcase,
  Clock,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { JobCard } from '../components/JobCard';
import { Button } from '../components/Button';
import { mockJobs } from '../data/mockJobs';
import { JobListing } from '../types';

export function Jobs() {
  const [titleQuery, setTitleQuery] = useState('');
  const [companyQuery, setCompanyQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [jobTypeFilter, setJobTypeFilter] = useState('All');
  const [experienceFilter, setExperienceFilter] = useState('All');
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);

  const locations = useMemo(
    () => ['All', ...Array.from(new Set(mockJobs.map((j) => j.location)))],
    []
  );
  const categories = useMemo(
    () => ['All', ...Array.from(new Set(mockJobs.map((j) => j.category)))],
    []
  );
  const jobTypes = useMemo(
    () => ['All', ...Array.from(new Set(mockJobs.map((j) => j.employmentType)))],
    []
  );
  const experiences = useMemo(
    () => ['All', ...Array.from(new Set(mockJobs.map((j) => j.experience)))],
    []
  );

  const filteredJobs = useMemo(() => {
    return mockJobs.filter((job) => {
      const matchesTitle = job.title.toLowerCase().includes(titleQuery.trim().toLowerCase());
      const matchesCompany = job.company.toLowerCase().includes(companyQuery.trim().toLowerCase());
      const matchesLocation = locationFilter === 'All' || job.location === locationFilter;
      const matchesCategory = categoryFilter === 'All' || job.category === categoryFilter;
      const matchesType = jobTypeFilter === 'All' || job.employmentType === jobTypeFilter;
      const matchesExperience =
        experienceFilter === 'All' || job.experience === experienceFilter;
      return (
        matchesTitle &&
        matchesCompany &&
        matchesLocation &&
        matchesCategory &&
        matchesType &&
        matchesExperience
      );
    });
  }, [
    titleQuery,
    companyQuery,
    locationFilter,
    categoryFilter,
    jobTypeFilter,
    experienceFilter
  ]);

  const hasActiveFilters =
    titleQuery !== '' ||
    companyQuery !== '' ||
    locationFilter !== 'All' ||
    categoryFilter !== 'All' ||
    jobTypeFilter !== 'All' ||
    experienceFilter !== 'All';

  const resetFilters = () => {
    setTitleQuery('');
    setCompanyQuery('');
    setLocationFilter('All');
    setCategoryFilter('All');
    setJobTypeFilter('All');
    setExperienceFilter('All');
  };

  return (
    <MainLayout>
      <section className="bg-white border-b border-slate-200 py-12 sm:py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold text-[#1D4ED8] mb-2">
              Explore Jobs · Demonstration Job Portal
            </p>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0B1936] tracking-tight">
              Discover graduate &amp; entry-level opportunities
            </h1>
            <p className="mt-2.5 text-base text-slate-600">
              Filter sample internships, graduate trainee tracks, and junior analyst openings by
              role, organization, location, and experience level.
            </p>
          </div>

          <div className="rounded-xl border border-blue-200 bg-blue-50/90 p-4 flex items-start gap-3 text-xs sm:text-sm text-[#0B1936]">
            <Info className="h-4 w-4 text-[#1D4ED8] shrink-0 mt-0.5" aria-hidden="true" />
            <p>
              <span className="font-semibold">Demonstration Content Only:</span> All 8 job listings
              displayed below are sample demonstration roles for Phase 1 UI testing and do not
              represent active vacancies.
            </p>
          </div>

          {/* Search and Filter Controls */}
          <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 sm:p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="search-job-title"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Search by Job Title
                </label>
                <div className="relative">
                  <Search
                    className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    id="search-job-title"
                    type="text"
                    value={titleQuery}
                    onChange={(e) => setTitleQuery(e.target.value)}
                    placeholder="e.g. Data Analyst, Management Trainee"
                    className="w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="search-company"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Search by Company
                </label>
                <div className="relative">
                  <Building2
                    className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                    aria-hidden="true"
                  />
                  <input
                    id="search-company"
                    type="text"
                    value={companyQuery}
                    onChange={(e) => setCompanyQuery(e.target.value)}
                    placeholder="e.g. Northbridge, Crestline"
                    className="w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label
                  htmlFor="filter-location"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Location
                </label>
                <select
                  id="filter-location"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                >
                  {locations.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc === 'All' ? 'All Locations' : loc}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="filter-category"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Category
                </label>
                <select
                  id="filter-category"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat === 'All' ? 'All Categories' : cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="filter-job-type"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Job Type
                </label>
                <select
                  id="filter-job-type"
                  value={jobTypeFilter}
                  onChange={(e) => setJobTypeFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                >
                  {jobTypes.map((type) => (
                    <option key={type} value={type}>
                      {type === 'All' ? 'All Job Types' : type}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="filter-experience"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Experience Level
                </label>
                <select
                  id="filter-experience"
                  value={experienceFilter}
                  onChange={(e) => setExperienceFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                >
                  {experiences.map((exp) => (
                    <option key={exp} value={exp}>
                      {exp === 'All' ? 'All Experience Levels' : exp}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
              <p className="tabular-nums">
                Showing <span className="font-bold text-[#0B1936]">{filteredJobs.length}</span> of{' '}
                <span className="font-bold text-[#0B1936]">{mockJobs.length}</span> demonstration
                jobs
              </p>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={resetFilters}>
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Reset Filters</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-14 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredJobs.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-4">
              <p className="text-lg font-bold text-[#0B1936]">No sample jobs match your filters</p>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Try clearing one or more search terms or dropdown filters to view all 8 demonstration
                listings.
              </p>
              <Button variant="secondary" size="sm" onClick={resetFilters}>
                Clear All Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredJobs.map((job) => (
                <JobCard key={job.id} job={job} onViewDetails={setSelectedJob} />
              ))}
            </div>
          )}
        </div>
      </section>

      {selectedJob && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="job-details-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-[#1D4ED8]">
                  Demonstration Content · {selectedJob.category}
                </p>
                <h2 id="job-details-title" className="text-2xl font-bold text-[#0B1936] mt-1">
                  {selectedJob.title}
                </h2>
                <p className="text-sm font-medium text-slate-700 mt-0.5">{selectedJob.company}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedJob(null)}
                aria-label="Close job details"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 border border-slate-200 rounded-xl p-4">
              <div className="space-y-1">
                <span className="text-slate-500 flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" aria-hidden="true" /> Location
                </span>
                <p className="font-semibold text-[#0B1936]">{selectedJob.location}</p>
              </div>
              <div className="space-y-1">
                <span className="text-slate-500 flex items-center gap-1">
                  <Briefcase className="h-3.5 w-3.5" aria-hidden="true" /> Type
                </span>
                <p className="font-semibold text-[#0B1936]">{selectedJob.employmentType}</p>
              </div>
              <div className="space-y-1">
                <span className="text-slate-500 flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" aria-hidden="true" /> Experience
                </span>
                <p className="font-semibold text-[#0B1936]">{selectedJob.experience}</p>
              </div>
              <div className="space-y-1 tabular-nums">
                <span className="text-slate-500 flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" aria-hidden="true" /> Deadline
                </span>
                <p className="font-semibold text-[#0B1936]">{selectedJob.deadline}</p>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-bold text-[#0B1936]">Role Overview</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{selectedJob.summary}</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-bold text-[#0B1936]">Sample Responsibilities</h3>
              <ul className="space-y-2">
                {selectedJob.responsibilities.map((resp) => (
                  <li key={resp} className="flex items-start gap-2.5 text-sm text-slate-700">
                    <CheckCircle2
                      className="h-4 w-4 text-[#0EA5E9] shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-1.5">
              <h3 className="text-sm font-bold text-[#0B1936]">Relevant Skills</h3>
              <p className="text-sm text-slate-600">{selectedJob.requiredSkills.join(' · ')}</p>
            </div>

            <div className="rounded-xl border border-blue-200 bg-blue-50 p-3.5 text-xs text-[#0B1936]">
              This is a demonstration job listing for Phase 1 UI evaluation. Live application
              submission and application tracking will be added in Phase 2.
            </div>

            <div className="flex justify-end gap-3 pt-1">
              <Button variant="secondary" size="sm" onClick={() => setSelectedJob(null)}>
                Close Details
              </Button>
              <Button to="/register" size="sm" onClick={() => setSelectedJob(null)}>
                Create Account Preview
              </Button>
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
