import { JobListing } from '../types';

export const mockJobs: JobListing[] = [
  {
    id: 'demo-job-1',
    title: 'Junior Business Data Analyst',
    company: 'Northbridge Logistics Group',
    location: 'Colombo (Hybrid)',
    category: 'Data & Analytics',
    employmentType: 'Full-Time',
    experience: '0–1 Years',
    deadline: '2026-12-12',
    salaryRange: 'Entry Competitive Package (Demo)',
    summary:
      'Support regional supply chain reporting using Excel modeling, operational dashboards, and weekly variance reviews.',
    responsibilities: [
      'Maintain weekly KPI workbooks using Pivot Tables, XLOOKUP, and conditional formatting.',
      'Summarize shipment turnaround trends for operations team leads.',
      'Audit dataset accuracy across warehouse dispatch logs.'
    ],
    requiredSkills: ['MS Excel', 'Analytical Thinking', 'Data Cleaning', 'Reporting'],
    isDemonstration: true
  },
  {
    id: 'demo-job-2',
    title: 'Management Trainee — Commercial Operations',
    company: 'Crestline Consumer Brands',
    location: 'Singapore (On-site)',
    category: 'Management Trainee',
    employmentType: 'Graduate Trainee',
    experience: 'Entry Level',
    deadline: '2026-12-18',
    salaryRange: 'Structured Trainee Allowance (Demo)',
    summary:
      '12-month rotational graduate program spanning category planning, vendor coordination, and field operations leadership.',
    responsibilities: [
      'Rotate across retail analytics, trade coordination, and inventory planning teams.',
      'Prepare executive briefing decks and monthly performance reviews.',
      'Collaborate with cross-functional leads to resolve delivery bottlenecks.'
    ],
    requiredSkills: ['Management Skills', 'Situation Handling', 'MS Excel', 'Communication'],
    isDemonstration: true
  },
  {
    id: 'demo-job-3',
    title: 'Finance & Reporting Intern',
    company: 'Harborview Advisory Partners',
    location: 'Kuala Lumpur (Hybrid)',
    category: 'Finance & Accounting',
    employmentType: 'Internship',
    experience: 'Student / Intern',
    deadline: '2026-12-08',
    salaryRange: 'Paid Internship Stipend (Demo)',
    summary:
      'Assist financial controllers with monthly reconciliation schedules, expense tracking, and client budget templates.',
    responsibilities: [
      'Prepare structured spreadsheet schedules and reconcile monthly ledger extracts.',
      'Support senior analysts during quarterly forecasting cycles.',
      'Document accounting workflow checklists for audit readiness.'
    ],
    requiredSkills: ['MS Excel', 'Financial Modeling Basics', 'Attention to Detail'],
    isDemonstration: true
  },
  {
    id: 'demo-job-4',
    title: 'Operations Coordinator',
    company: 'Veridian Health Systems',
    location: 'Remote (Regional)',
    category: 'Business Operations',
    employmentType: 'Full-Time',
    experience: '1–2 Years',
    deadline: '2026-12-22',
    salaryRange: 'Standard Associate Band (Demo)',
    summary:
      'Coordinate clinic onboarding schedules, vendor SLAs, and service escalation tracking across regional partner hubs.',
    responsibilities: [
      'Track service request queues and resolve scheduling conflicts proactively.',
      'Maintain weekly operational scorecards and turnaround summaries.',
      'Coordinate stakeholder updates across support and onboarding specialists.'
    ],
    requiredSkills: ['Situation Handling', 'Process Coordination', 'MS Excel', 'Stakeholder Alignment'],
    isDemonstration: true
  },
  {
    id: 'demo-job-5',
    title: 'Digital Growth & Campaign Associate',
    company: 'BeaconPulse Media',
    location: 'Bangalore (Hybrid)',
    category: 'Marketing & Growth',
    employmentType: 'Full-Time',
    experience: '0–1 Years',
    deadline: '2026-12-15',
    salaryRange: 'Junior Associate Package (Demo)',
    summary:
      'Analyze campaign conversion funnels, manage content calendars, and build weekly attribution summaries for B2B clients.',
    responsibilities: [
      'Track acquisition funnel metrics across search, email, and social channels.',
      'Compile campaign performance reports with actionable optimization notes.',
      'Coordinate asset timelines with design and copy teams.'
    ],
    requiredSkills: ['Analytical Skills', 'Reporting', 'Campaign Coordination', 'MS Excel'],
    isDemonstration: true
  },
  {
    id: 'demo-job-6',
    title: 'People Operations & Talent Assistant',
    company: 'Solstice Tech Services',
    location: 'Remote (Global)',
    category: 'Human Resources',
    employmentType: 'Part-Time',
    experience: 'Student / Intern',
    deadline: '2026-12-20',
    salaryRange: 'Flexible Part-Time Stipend (Demo)',
    summary:
      'Support candidate screening logistics, onboarding documentation, and university campus outreach events.',
    responsibilities: [
      'Schedule structured interviews and maintain candidate pipeline trackers.',
      'Prepare onboarding welcome packs and orientation checklists.',
      'Assist HR leads with quarterly engagement survey summaries.'
    ],
    requiredSkills: ['Situation Handling', 'Communication', 'Spreadsheet Tracking'],
    isDemonstration: true
  },
  {
    id: 'demo-job-7',
    title: 'Associate Financial Operations Analyst',
    company: 'Meridian FinServe',
    location: 'Colombo (On-site)',
    category: 'Finance & Accounting',
    employmentType: 'Full-Time',
    experience: '0–1 Years',
    deadline: '2026-12-28',
    salaryRange: 'Graduate Associate Band (Demo)',
    summary:
      'Monitor settlement exceptions, automate recurring Excel reconciliation checks, and support treasury reporting.',
    responsibilities: [
      'Investigate daily transaction variances and document resolution paths.',
      'Build summary pivot reports for senior risk and treasury managers.',
      'Standardize operational SOPs for recurring settlement workflows.'
    ],
    requiredSkills: ['MS Excel', 'Analytical Skills', 'Risk Awareness', 'Documentation'],
    isDemonstration: true
  },
  {
    id: 'demo-job-8',
    title: 'Supply Chain Planning Intern',
    company: 'Atlas Maritime Commerce',
    location: 'Singapore (Hybrid)',
    category: 'Business Operations',
    employmentType: 'Internship',
    experience: 'Student / Intern',
    deadline: '2026-12-19',
    salaryRange: 'Internship Allowance (Demo)',
    summary:
      'Support demand planners with inventory safety-stock sheets, vendor lead-time logs, and shipment status trackers.',
    responsibilities: [
      'Update weekly stock-cover spreadsheets and flag low-inventory SKUs.',
      'Coordinate lead-time confirmations with regional freight partners.',
      'Summarize weekly supplier fulfillment metrics.'
    ],
    requiredSkills: ['MS Excel', 'Analytical Skills', 'Coordination'],
    isDemonstration: true
  }
];
