import { useState } from 'react';
import {
  Clock,
  HelpCircle,
  Award,
  CheckCircle2,
  Info,
  Play,
  ArrowRight
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/Button';
import { assessmentBreakdown } from '../data/mockDashboard';

export function Assessment() {
  const [selectedId, setSelectedId] = useState<string>(assessmentBreakdown[0].id);
  const [engineNoticeOpen, setEngineNoticeOpen] = useState(false);

  const activeCategory =
    assessmentBreakdown.find((c) => c.id === selectedId) ?? assessmentBreakdown[0];

  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-white to-slate-50 border-b border-slate-200 py-14 sm:py-18">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-7 space-y-5">
              <p className="text-sm font-semibold text-[#1D4ED8]">Skill Assessment Blueprint</p>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B1936] tracking-tight text-balance">
                Evaluate core workplace skills in 20 focused minutes
              </h1>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
                Our standardized evaluation measures practical MS Excel fluency, workplace situation
                handling, analytical reasoning, and foundational management capability.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3.5">
                <Button size="lg" onClick={() => setEngineNoticeOpen(true)}>
                  <Play className="h-4 w-4" aria-hidden="true" />
                  <span>Start Assessment</span>
                </Button>
                <Button to="/dashboard" variant="secondary" size="lg">
                  <span>View Sample Score Report</span>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Button>
              </div>

              {engineNoticeOpen && (
                <div
                  role="status"
                  className="mt-4 rounded-xl border border-blue-200 bg-blue-50 p-4 flex items-start gap-3 text-sm text-[#0B1936]"
                >
                  <Info className="h-5 w-5 text-[#1D4ED8] shrink-0 mt-0.5" aria-hidden="true" />
                  <div className="space-y-1">
                    <p className="font-semibold">
                      Assessment Engine Planned for Later Development Phase
                    </p>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      Phase 1 presents the assessment architecture and topic weighting. The actual
                      timed assessment engine, question bank, and automated scoring will be
                      developed in a later phase.
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-[#0B1936]">Planned Assessment Structure</h2>
                <p className="text-xs text-slate-500 mt-1">
                  Standardized 1-mark-per-question scoring blueprint
                </p>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-4">
                  <HelpCircle className="h-4 w-4 text-[#1D4ED8] mx-auto mb-1.5" aria-hidden="true" />
                  <p className="text-2xl font-extrabold text-[#0B1936] tabular-nums">20</p>
                  <p className="text-xs text-slate-600 mt-0.5">Total Questions</p>
                </div>
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-4">
                  <Clock className="h-4 w-4 text-[#1D4ED8] mx-auto mb-1.5" aria-hidden="true" />
                  <p className="text-2xl font-extrabold text-[#0B1936] tabular-nums">20</p>
                  <p className="text-xs text-slate-600 mt-0.5">Minutes</p>
                </div>
                <div className="rounded-xl bg-slate-50 border border-slate-200 p-4">
                  <Award className="h-4 w-4 text-[#1D4ED8] mx-auto mb-1.5" aria-hidden="true" />
                  <p className="text-2xl font-extrabold text-[#0B1936] tabular-nums">20</p>
                  <p className="text-xs text-slate-600 mt-0.5">Total Marks</p>
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-slate-100">
                <p className="text-xs font-semibold text-[#0B1936]">Question Distribution</p>
                <div className="h-3 w-full rounded-full overflow-hidden flex bg-slate-100">
                  <div className="bg-[#0B1936] h-full" style={{ width: '60%' }} title="MS Excel 60%" />
                  <div
                    className="bg-[#1D4ED8] h-full"
                    style={{ width: '20%' }}
                    title="Situation Handling 20%"
                  />
                  <div
                    className="bg-[#0EA5E9] h-full"
                    style={{ width: '10%' }}
                    title="Analytical Skills 10%"
                  />
                  <div
                    className="bg-[#4F46E5] h-full"
                    style={{ width: '10%' }}
                    title="Management Skills 10%"
                  />
                </div>
                <ul className="space-y-2 text-sm">
                  {assessmentBreakdown.map((item) => (
                    <li
                      key={item.id}
                      className="flex items-center justify-between text-slate-700 tabular-nums"
                    >
                      <span className="font-medium">{item.name}</span>
                      <span className="font-mono text-xs text-slate-600">
                        {item.questions} Questions ({item.percentage}%)
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Domain Topic Explorer */}
      <section className="py-14 sm:py-18 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#0B1936]">
              Explore Competency Domains
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-2">
              Select a domain below to review the planned question weighting and topics evaluated.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
              {assessmentBreakdown.map((cat) => {
                const isSelected = cat.id === activeCategory.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedId(cat.id)}
                    className={`text-left rounded-xl border p-4 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#0B1936] border-[#0B1936] text-white shadow-sm'
                        : 'bg-white border-slate-200 text-slate-900 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-bold text-base">{cat.name}</span>
                      <span
                        className={`font-mono text-xs font-semibold tabular-nums ${
                          isSelected ? 'text-[#38BDF8]' : 'text-[#1D4ED8]'
                        }`}
                      >
                        {cat.questions} Qs · {cat.percentage}%
                      </span>
                    </div>
                    <p
                      className={`text-xs mt-1.5 ${
                        isSelected ? 'text-slate-300' : 'text-slate-500'
                      }`}
                    >
                      {cat.marks} Marks total weight
                    </p>
                  </button>
                );
              })}
            </div>

            <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-100">
                <div>
                  <p className="text-xs font-semibold text-[#1D4ED8]">Selected Assessment Domain</p>
                  <h3 className="text-2xl font-bold text-[#0B1936] mt-1">{activeCategory.name}</h3>
                </div>
                <div className="text-right tabular-nums">
                  <p className="text-2xl font-extrabold text-[#0B1936]">
                    {activeCategory.questions} Questions
                  </p>
                  <p className="text-xs text-slate-500">
                    {activeCategory.percentage}% of total assessment
                  </p>
                </div>
              </div>

              <p className="text-sm text-slate-600 leading-relaxed">
                {activeCategory.sampleContext}
              </p>

              <div className="space-y-3">
                <h4 className="text-sm font-bold text-[#0B1936]">Topics Evaluated</h4>
                <ul className="space-y-2.5">
                  {activeCategory.focusTopics.map((topic) => (
                    <li key={topic} className="flex items-start gap-2.5 text-sm text-slate-700">
                      <CheckCircle2
                        className="h-4 w-4 text-[#0EA5E9] shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span>{topic}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
