import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';

interface FeatureCardProps {
  title: string;
  description: string;
  items: string[];
  icon: React.ReactNode;
  to: string;
  ctaLabel: string;
}

export function FeatureCard({
  title,
  description,
  items,
  icon,
  to,
  ctaLabel
}: FeatureCardProps) {
  return (
    <article className="group flex flex-col justify-between bg-white rounded-xl border border-slate-200 p-6 sm:p-7 transition-all duration-150 hover:border-blue-300 hover:shadow-md">
      <div>
        <div className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8] mb-5">
          {icon}
        </div>
        <h3 className="text-xl font-bold text-[#0B1936] mb-2">{title}</h3>
        <p className="text-sm text-slate-600 leading-relaxed mb-5">{description}</p>
        <ul className="space-y-2.5 mb-6">
          {items.map((item) => (
            <li key={item} className="flex items-start gap-2.5 text-sm text-slate-700">
              <Check className="h-4 w-4 text-[#0EA5E9] shrink-0 mt-0.5" aria-hidden="true" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <Link
        to={to}
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#1D4ED8] hover:text-[#0B1936] transition-colors whitespace-nowrap shrink-0"
      >
        <span>{ctaLabel}</span>
        <ArrowRight
          className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5"
          aria-hidden="true"
        />
      </Link>
    </article>
  );
}
