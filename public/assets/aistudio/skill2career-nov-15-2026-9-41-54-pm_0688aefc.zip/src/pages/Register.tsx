import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Info, User, Mail, Phone, GraduationCap, ArrowRight } from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/Button';

const qualificationOptions = [
  'Undergraduate Student',
  "Bachelor's Degree (Graduate)",
  "Master's Degree",
  'Higher National Diploma / Associate',
  'Professional Certificate Track'
];

export function Register() {
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    mobile: '',
    qualification: ''
  });
  const [validationError, setValidationError] = useState('');
  const [phaseNotice, setPhaseNotice] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.fullName.trim().length < 2) {
      setValidationError('Please enter your full name.');
      setPhaseNotice(false);
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      setValidationError('Please enter a valid email address.');
      setPhaseNotice(false);
      return;
    }
    if (!/^[+\d\s()-]{7,20}$/.test(form.mobile.trim())) {
      setValidationError('Please enter a valid mobile number (7–20 digits).');
      setPhaseNotice(false);
      return;
    }
    if (!form.qualification) {
      setValidationError('Please select your educational qualification.');
      setPhaseNotice(false);
      return;
    }

    setValidationError('');
    setPhaseNotice(true);
  };

  const handleSocialPlaceholder = () => {
    setValidationError('');
    setPhaseNotice(true);
  };

  return (
    <MainLayout>
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-lg mx-auto bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-[#0B1936]">Create Your Skill2Career Account</h1>
            <p className="text-sm text-slate-600 mt-1.5">
              Join as a university student or recent graduate to build your skill profile.
            </p>
          </div>

          {phaseNotice && (
            <div
              role="status"
              className="mb-6 rounded-xl border border-blue-200 bg-blue-50 p-4 flex items-start gap-3 text-sm text-[#0B1936]"
            >
              <Info className="h-5 w-5 text-[#1D4ED8] shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-semibold">
                  Authentication will be available in the next development phase.
                </p>
                <p className="text-xs text-slate-600 mt-1">
                  Your form fields passed client-side validation. Meanwhile, explore the{' '}
                  <Link to="/dashboard" className="font-semibold text-[#1D4ED8] underline">
                    Student Dashboard Preview
                  </Link>{' '}
                  or{' '}
                  <Link to="/assessment" className="font-semibold text-[#1D4ED8] underline">
                    Skill Assessment Blueprint
                  </Link>
                  .
                </p>
              </div>
            </div>
          )}

          {validationError && (
            <div
              role="alert"
              className="mb-5 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700"
            >
              {validationError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            <button
              type="button"
              onClick={handleSocialPlaceholder}
              className="flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span className="font-bold text-[#1D4ED8]" aria-hidden="true">
                G
              </span>
              <span>Google Login</span>
            </button>
            <button
              type="button"
              onClick={handleSocialPlaceholder}
              className="flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span className="font-bold text-[#0A66C2]" aria-hidden="true">
                in
              </span>
              <span>LinkedIn Login</span>
            </button>
          </div>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-white px-3 text-slate-500">Or register with your details</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div>
              <label htmlFor="reg-fullname" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Full Name
              </label>
              <div className="relative">
                <User
                  className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
                <input
                  id="reg-fullname"
                  type="text"
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  placeholder="Aarav Perera"
                  required
                  className="w-full rounded-lg border border-slate-300 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="reg-email" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail
                  className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
                <input
                  id="reg-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="student@university.edu"
                  required
                  className="w-full rounded-lg border border-slate-300 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="reg-mobile" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Mobile Number
              </label>
              <div className="relative">
                <Phone
                  className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
                <input
                  id="reg-mobile"
                  type="tel"
                  value={form.mobile}
                  onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                  placeholder="+94 77 123 4567"
                  required
                  className="w-full rounded-lg border border-slate-300 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label htmlFor="reg-qualification" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Educational Qualification
              </label>
              <div className="relative">
                <GraduationCap
                  className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <select
                  id="reg-qualification"
                  value={form.qualification}
                  onChange={(e) => setForm({ ...form, qualification: e.target.value })}
                  required
                  className="w-full rounded-lg border border-slate-300 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent"
                >
                  <option value="">Select your qualification</option>
                  {qualificationOptions.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <Button type="submit" size="md" className="w-full mt-2">
              <span>Create Free Account</span>
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Button>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-100 space-y-3 text-center text-sm text-slate-600">
            <p>
              Already registered?{' '}
              <Link to="/login" className="font-semibold text-[#1D4ED8] hover:underline">
                Sign in
              </Link>
            </p>
            <p className="text-xs">
              Want to see the platform first?{' '}
              <Link to="/dashboard" className="font-semibold text-[#0B1936] hover:underline">
                Preview Student Dashboard
              </Link>
            </p>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
