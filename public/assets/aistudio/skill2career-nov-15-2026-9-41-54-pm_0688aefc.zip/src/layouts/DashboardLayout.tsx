import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  ClipboardCheck,
  FileText,
  Briefcase,
  BookOpen,
  ArrowLeft,
  Compass,
  Menu,
  X,
  Info
} from 'lucide-react';
import { Button } from '../components/Button';

interface DashboardLayoutProps {
  pageTitle: string;
  breadcrumb: string;
  children: React.ReactNode;
}

const sidebarNav = [
  { label: 'Student Dashboard', to: '/dashboard', icon: LayoutDashboard },
  { label: 'Skill Assessment', to: '/assessment', icon: ClipboardCheck },
  { label: 'Resume Builder', to: '/resume-builder', icon: FileText },
  { label: 'Explore Jobs', to: '/jobs', icon: Briefcase },
  { label: 'How It Works', to: '/how-it-works', icon: BookOpen }
];

export function DashboardLayout({ pageTitle, breadcrumb, children }: DashboardLayoutProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#0B1936] text-slate-200">
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
        <Link
          to="/"
          className="flex items-center gap-2.5 text-base font-bold text-white whitespace-nowrap"
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#2563EB] to-[#0EA5E9] text-white">
            <Compass className="h-4 w-4" aria-hidden="true" />
          </span>
          <span>Skill2Career</span>
        </Link>
        <button
          type="button"
          onClick={() => setDrawerOpen(false)}
          aria-label="Close sidebar"
          className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="px-4 py-5 flex-1 space-y-1.5 overflow-y-auto">
        <p className="px-3 pb-2 text-xs font-medium text-slate-400">Workspace Preview</p>
        {sidebarNav.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setDrawerOpen(false)}
              className={({ isActive }) =>
                [
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap',
                  isActive
                    ? 'bg-[#1D4ED8] text-white'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                ].join(' ')
              }
            >
              <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </div>

      <div className="p-4 border-t border-slate-800 space-y-3">
        <div className="rounded-lg bg-[#132852] p-3.5 text-xs text-slate-300 leading-relaxed">
          <p className="font-semibold text-white mb-1">Phase 1 Preview Mode</p>
          <p>
            Sample student data shown. Authentication and Supabase persistence arrive in Phase 2.
          </p>
        </div>
        <Link
          to="/"
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Back to Public Site</span>
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        {sidebarContent}
      </aside>

      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[85vw] h-full z-10">{sidebarContent}</aside>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 h-16 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              aria-label="Open workspace navigation"
              className="lg:hidden inline-flex items-center justify-center h-10 w-10 rounded-lg text-slate-700 hover:bg-slate-100"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <p className="text-xs text-slate-500 truncate">{breadcrumb}</p>
              <h1 className="text-base sm:text-lg font-bold text-[#0B1936] truncate">{pageTitle}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <Button to="/register" size="sm">
              Create Account Preview
            </Button>
          </div>
        </header>

        <div className="bg-blue-50/90 border-b border-blue-200/80 px-4 sm:px-6 lg:px-8 py-2.5">
          <div className="max-w-7xl mx-auto flex items-center gap-2.5 text-xs sm:text-sm text-[#0B1936]">
            <Info className="h-4 w-4 text-[#1D4ED8] shrink-0" aria-hidden="true" />
            <p>
              <span className="font-semibold">Demonstration Data Notice:</span> This Student
              Dashboard displays sample profile metrics, mock skill scores, and preview job matches
              for Phase 1 evaluation.
            </p>
          </div>
        </div>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}
