import { Calendar, MapPin, Briefcase, Clock } from 'lucide-react';
import { JobListing } from '../types';
import { Button } from './Button';

interface JobCardProps {
  job: JobListing;
  onViewDetails: (job: JobListing) => void;
}

export function JobCard({ job, onViewDetails }: JobCardProps) {
  return (
    <article className="flex flex-col justify-between bg-white rounded-xl border border-slate-200 p-6 transition-all duration-150 hover:border-blue-300 hover:shadow-md">
      <div>
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500 mb-2">
          <span className="font-medium text-[#1D4ED8]">{job.category}</span>
          <span aria-hidden="true">·</span>
          <span>Demonstration Sample</span>
        </div>

        <h3 className="text-lg font-bold text-[#0B1936] leading-snug mb-1">{job.title}</h3>
        <p className="text-sm font-medium text-slate-700 mb-4">{job.company}</p>

        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-y-2.5 gap-x-4 text-xs text-slate-600 mb-5">
          <div className="flex items-center gap-2">
            <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span className="truncate">{job.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Briefcase className="h-3.5 w-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span>{job.employmentType}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-3.5 w-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span>{job.experience}</span>
          </div>
          <div className="flex items-center gap-2 tabular-nums">
            <Calendar className="h-3.5 w-3.5 text-slate-400 shrink-0" aria-hidden="true" />
            <span>Deadline: {job.deadline}</span>
          </div>
        </dl>
      </div>

      <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
        <span className="text-xs text-slate-500 truncate">{job.salaryRange}</span>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => onViewDetails(job)}
          aria-label={`View details for ${job.title} at ${job.company}`}
        >
          View Details
        </Button>
      </div>
    </article>
  );
}
