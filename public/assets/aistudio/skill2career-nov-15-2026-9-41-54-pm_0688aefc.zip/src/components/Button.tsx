import React from 'react';
import { Link } from 'react-router-dom';

type ButtonVariant = 'primary' | 'secondary' | 'navy' | 'ghost';
type ButtonSize = 'sm' | 'md' | 'lg';

interface BaseProps {
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  children: React.ReactNode;
}

type ButtonAsButton = BaseProps &
  React.ButtonHTMLAttributes<HTMLButtonElement> & {
    to?: undefined;
  };

type ButtonAsLink = BaseProps & {
  to: string;
  onClick?: () => void;
};

export type ButtonProps = ButtonAsButton | ButtonAsLink;

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    'bg-gradient-to-r from-[#1D4ED8] via-[#2563EB] to-[#4F46E5] text-white shadow-sm hover:brightness-110 active:scale-[0.99]',
  secondary:
    'bg-white text-slate-800 border border-slate-300 hover:border-slate-400 hover:bg-slate-50',
  navy: 'bg-[#0B1936] text-white hover:bg-[#132852]',
  ghost: 'bg-transparent text-slate-700 hover:bg-slate-100 hover:text-slate-900'
};

const sizeClasses: Record<ButtonSize, string> = {
  sm: 'px-3.5 py-2 text-xs',
  md: 'px-5 py-2.5 text-sm',
  lg: 'px-6 py-3 text-sm sm:text-base'
};

export function Button({
  variant = 'primary',
  size = 'md',
  className = '',
  children,
  ...rest
}: ButtonProps) {
  const classes = [
    'inline-flex items-center justify-center gap-2 rounded-lg font-medium whitespace-nowrap shrink-0',
    'transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] focus-visible:ring-offset-2',
    'disabled:opacity-60 disabled:pointer-events-none cursor-pointer',
    variantClasses[variant],
    sizeClasses[size],
    className
  ].join(' ');

  if ('to' in rest && typeof rest.to === 'string') {
    return (
      <Link to={rest.to} onClick={rest.onClick} className={classes}>
        {children}
      </Link>
    );
  }

  const buttonProps = rest as React.ButtonHTMLAttributes<HTMLButtonElement>;
  return (
    <button type={buttonProps.type ?? 'button'} className={classes} {...buttonProps}>
      {children}
    </button>
  );
}
