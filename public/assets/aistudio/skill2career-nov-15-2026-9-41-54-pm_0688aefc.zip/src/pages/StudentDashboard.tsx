import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle2,
  Circle,
  ArrowRight,
  BookOpen,
  Briefcase,
  FileText,
  Clock,
  X,
  MapPin,
  Calendar
} from 'lucide-react';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { DashboardCard } from '../components/DashboardCard';
import { Button } from '../components/Button';
import { mockDashboardData } from '../data/mockDashboard';
import { mockJobs } from '../data/mockJobs';
import { JobListing, LearningResource } from '../types';

export function StudentDashboard() {
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);
  const [selectedResource, setSelectedResource] = useState<LearningResource | null>(null);
  const [resourceFilter, setResourceFilter] = useState<string>('All');

  const recommendedJobs = mockJobs.filter((job) =>
    mockDashboardData.recommendedJobIds.includes(job.id)
  );

  const skillAreas = ['All', ...Array.from(new Set(mockDashboardData.learningResources.map((r) => r.skillArea)))];
  const filteredResources =
    resourceFilter === 'All'
      ? mockDashboardData.learningResources
      : mockDashboardData.learningResources.filter((r) => r.skillArea === resourceFilter);

  return (
    <DashboardLayout
      pageTitle="Student Dashboard Preview"
      breadcrumb="Skill2Career / Workspace / Overview (Demonstration Data)"
    >
      <div className="space-y-6">
        {/* Welcome & Top KPI Strip */}
        <section className="bg-gradient-to-r from-[#0B1936] via-[#132852] to-[#1D4ED8] text-white rounded-2xl p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <p className="text-xs font-medium text-[#38BDF8]">
                Demonstration Student Profile · {mockDashboardData.student.university}
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Welcome back, {mockDashboardData.student.fullName}
              </h2>
              <p className="text-sm text-slate-200">
                {mockDashboardData.student.qualification} · Target Role:{' '}
                <span className="font-semibold text-white">
                  {mockDashboardData.student.targetRole}
                </span>
              </p>
            </div>

            <div className="flex flex-wrap gap-3 shrink-0">
              <Button to="/assessment" size="sm" variant="secondary">
                Preview Assessment
              </Button>
              <Button to="/resume-builder" size="sm">
                Open CV Builder Preview
              </Button>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-white/15 grid grid-cols-1 sm:grid-cols-3 gap-5">
            <div>
              <p className="text-xs text-slate-300">Profile Completion (Demo)</p>
              <div className="mt-1 flex items-baseline gap-2 tabular-nums">
                <span className="text-2xl font-bold">
                  {mockDashboardData.profileCompletion.percentage}%
                </span>
                <span className="text-xs text-slate-300">3 of 5 milestones</span>
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-300">Career Score Preview (Sample)</p>
              <div className="mt-1 flex items-baseline gap-2 tabular-nums">
                <span className="text-2xl font-bold">
                  {mockDashboardData.careerScore.overall}
                </span>
                <span className="text-xs text-slate-300">
                  / {mockDashboardData.careerScore.max} ·{' '}
                  {mockDashboardData.careerScore.readinessLabel}
                </span>
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-300">CV Completion Status (Demo)</p>
              <div className="mt-1 flex items-baseline gap-2 tabular-nums">
                <span className="text-2xl font-bold">{mockDashboardData.cvStatus.percentage}%</span>
                <span className="text-xs text-slate-300">
                  {mockDashboardData.cvStatus.templateName}
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Main Analytical Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Skill Assessment Summary */}
          <DashboardCard
            title="Skill Assessment Summary"
            subtitle="Sample competency distribution across 4 core tracks (Demo)"
            className="lg:col-span-7"
            action={
              <Link
                to="/assessment"
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap"
              >
                <span>View Blueprint</span>
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </Link>
            }
          >
            <div className="space-y-4">
              {mockDashboardData.skillSummary.map((skill) => (
                <div key={skill.id} className="space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                    <span className="font-semibold text-[#0B1936]">{skill.name}</span>
                    <div className="flex items-center gap-2 text-xs tabular-nums">
                      <span
                        className={
                          skill.status === 'Strong'
                            ? 'text-emerald-700 font-medium'
                            : skill.status === 'Developing'
                              ? 'text-[#1D4ED8] font-medium'
                              : 'text-amber-700 font-medium'
                        }
                      >
                        {skill.status}
                      </span>
                      <span aria-hidden="true" className="text-slate-300">
                        ·
                      </span>
                      <span className="font-mono font-semibold text-[#0B1936]">
                        {skill.score}/{skill.maxScore}
                      </span>
                    </div>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#1D4ED8] to-[#0EA5E9]"
                      style={{ width: `${skill.score}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-500">{skill.benchmarkNote}</p>
                </div>
              ))}
            </div>
          </DashboardCard>

          {/* Profile Completion & Career Score Note */}
          <DashboardCard
            title="Profile Completion Checklist"
            subtitle="Sample onboarding milestones for Phase 1 preview"
            className="lg:col-span-5"
          >
            <div className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-medium text-slate-700 tabular-nums">
                  <span>Overall Progress</span>
                  <span>{mockDashboardData.profileCompletion.percentage}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#1D4ED8]"
                    style={{ width: `${mockDashboardData.profileCompletion.percentage}%` }}
                  />
                </div>
              </div>

              <ul className="divide-y divide-slate-100">
                {mockDashboardData.profileCompletion.checklist.map((item) => (
                  <li key={item.id} className="py-2.5 flex items-start gap-2.5 text-sm">
                    {item.completed ? (
                      <CheckCircle2
                        className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                    ) : (
                      <Circle
                        className="h-4 w-4 text-slate-300 shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                    )}
                    <span className={item.completed ? 'text-slate-800' : 'text-slate-500'}>
                      {item.label}
                    </span>
                  </li>
                ))}
              </ul>

              <p className="text-xs text-slate-500 pt-2 border-t border-slate-100 leading-relaxed">
                {mockDashboardData.careerScore.summary}
              </p>
            </div>
          </DashboardCard>
        </div>

        {/* CV Status & Recommended Jobs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <DashboardCard
            title="CV Completion Status"
            subtitle={`${mockDashboardData.cvStatus.templateName} · ${mockDashboardData.cvStatus.lastUpdated}`}
            className="lg:col-span-5"
            action={
              <Link
                to="/resume-builder"
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap"
              >
                <span>Open Builder</span>
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </Link>
            }
          >
            <div className="divide-y divide-slate-100">
              {mockDashboardData.cvStatus.sections.map((sec) => (
                <div key={sec.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-sm font-semibold text-[#0B1936]">
                      <FileText className="h-4 w-4 text-slate-400 shrink-0" aria-hidden="true" />
                      <span>{sec.section}</span>
                    </div>
                    <span
                      className={`text-xs font-medium ${
                        sec.status === 'Complete'
                          ? 'text-emerald-700'
                          : sec.status === 'In Progress'
                            ? 'text-[#1D4ED8]'
                            : 'text-slate-500'
                      }`}
                    >
                      {sec.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1 pl-6">{sec.detail}</p>
                </div>
              ))}
            </div>
          </DashboardCard>

          <DashboardCard
            title="Recommended Jobs (Sample Listings)"
            subtitle="Demonstration vacancies aligned to sample student profile"
            className="lg:col-span-7"
            action={
              <Link
                to="/jobs"
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:underline whitespace-nowrap"
              >
                <span>Explore All Jobs</span>
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </Link>
            }
          >
            <div className="divide-y divide-slate-100">
              {recommendedJobs.map((job) => (
                <div
                  key={job.id}
                  className="py-3.5 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <h3 className="text-sm font-bold text-[#0B1936]">{job.title}</h3>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {job.company} · {job.location} · {job.employmentType}
                    </p>
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setSelectedJob(job)}
                  >
                    View Sample
                  </Button>
                </div>
              ))}
            </div>
          </DashboardCard>
        </div>

        {/* Learning Resources & Recent Activities */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <DashboardCard
            title="Recommended Learning Resources"
            subtitle="Targeted guides for identified sample skill gaps"
            className="lg:col-span-7"
            action={
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                {skillAreas.map((area) => (
                  <button
                    key={area}
                    type="button"
                    onClick={() => setResourceFilter(area)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      resourceFilter === area
                        ? 'bg-white text-[#0B1936] shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {area}
                  </button>
                ))}
              </div>
            }
          >
            <div className="space-y-3">
              {filteredResources.map((res) => (
                <div
                  key={res.id}
                  className="rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-blue-300 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-semibold text-[#1D4ED8]">{res.skillArea}</span>
                      <span aria-hidden="true">·</span>
                      <span>{res.format}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{res.duration}</span>
                    </div>
                    <h3 className="text-sm font-bold text-[#0B1936]">{res.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">{res.description}</p>
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setSelectedResource(res)}
                  >
                    <BookOpen className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Preview</span>
                  </Button>
                </div>
              ))}
            </div>
          </DashboardCard>

          <DashboardCard
            title="Recent Activities (Demo)"
            subtitle="Simulated timeline of student platform actions"
            className="lg:col-span-5"
          >
            <ol className="divide-y divide-slate-100">
              {mockDashboardData.recentActivities.map((act) => (
                <li key={act.id} className="py-3 first:pt-0 last:pb-0 space-y-1">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="font-medium text-[#1D4ED8]">{act.category}</span>
                    <span className="tabular-nums flex items-center gap-1">
                      <Clock className="h-3 w-3" aria-hidden="true" />
                      {act.timestamp}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-[#0B1936]">{act.action}</p>
                  <p className="text-xs text-slate-600">{act.detail}</p>
                </li>
              ))}
            </ol>
          </DashboardCard>
        </div>
      </div>

      {/* Job Detail Modal */}
      {selectedJob && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="dash-job-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-[#1D4ED8]">
                  Demonstration Sample Vacancy · {selectedJob.category}
                </p>
                <h3 id="dash-job-modal-title" className="text-xl font-bold text-[#0B1936] mt-1">
                  {selectedJob.title}
                </h3>
                <p className="text-sm text-slate-600">{selectedJob.company}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedJob(null)}
                aria-label="Close job preview"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="flex flex-wrap gap-4 text-xs text-slate-600 border-y border-slate-100 py-3">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-slate-400" />
                {selectedJob.location}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Briefcase className="h-3.5 w-3.5 text-slate-400" />
                {selectedJob.employmentType}
              </span>
              <span className="inline-flex items-center gap-1.5 tabular-nums">
                <Calendar className="h-3.5 w-3.5 text-slate-400" />
                Deadline: {selectedJob.deadline}
              </span>
            </div>

            <p className="text-sm text-slate-700 leading-relaxed">{selectedJob.summary}</p>
            <div>
              <p className="text-xs font-semibold text-[#0B1936] mb-1.5">Key Skills</p>
              <p className="text-xs text-slate-600">{selectedJob.requiredSkills.join(' · ')}</p>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <Button variant="secondary" size="sm" onClick={() => setSelectedJob(null)}>
                Close
              </Button>
              <Button to="/jobs" size="sm" onClick={() => setSelectedJob(null)}>
                Open Job Portal
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Learning Resource Modal */}
      {selectedResource && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="dash-res-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-[#1D4ED8]">
                  Demonstration Learning Module · {selectedResource.skillArea}
                </p>
                <h3 id="dash-res-modal-title" className="text-lg font-bold text-[#0B1936] mt-1">
                  {selectedResource.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedResource(null)}
                aria-label="Close resource preview"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              {selectedResource.description}
            </p>
            <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg p-3">
              Interactive practice sheets and guided exercises will be connected in Phase 2 when
              user progress tracking goes live.
            </p>
            <div className="flex justify-end">
              <Button size="sm" onClick={() => setSelectedResource(null)}>
                Close Preview
              </Button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
