import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { HowItWorks } from './pages/HowItWorks';
import { Assessment } from './pages/Assessment';
import { ResumeBuilder } from './pages/ResumeBuilder';
import { Jobs } from './pages/Jobs';
import { StudentDashboard } from './pages/StudentDashboard';
import { MainLayout } from './layouts/MainLayout';
import { Button } from './components/Button';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function NotFoundPage() {
  return (
    <MainLayout>
      <section className="py-20 px-4 text-center max-w-lg mx-auto space-y-4">
        <p className="font-mono text-sm font-semibold text-[#1D4ED8]">404</p>
        <h1 className="text-3xl font-bold text-[#0B1936]">Page not found</h1>
        <p className="text-sm text-slate-600">
          The page you requested does not exist in this Skill2Career Phase 1 preview.
        </p>
        <div className="pt-2">
          <Button to="/" size="md">
            Return to Home
          </Button>
        </div>
      </section>
    </MainLayout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/assessment" element={<Assessment />} />
        <Route path="/resume-builder" element={<ResumeBuilder />} />
        <Route path="/jobs" element={<Jobs />} />
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
