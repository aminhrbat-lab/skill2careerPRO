import { useState } from 'react';
import {
  Upload,
  FilePlus2,
  LayoutTemplate,
  Wand2,
  Target,
  MailCheck,
  Download,
  Info,
  CheckCircle2
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/Button';
import { cvTemplatesPreview } from '../data/mockDashboard';

export function ResumeBuilder() {
  const [selectedTemplateId, setSelectedTemplateId] = useState(cvTemplatesPreview[0].id);
  const [previewNotice, setPreviewNotice] = useState<string | null>(null);

  const selectedTemplate =
    cvTemplatesPreview.find((tpl) => tpl.id === selectedTemplateId) ?? cvTemplatesPreview[0];

  const triggerPhaseNotice = (featureName: string) => {
    setPreviewNotice(
      `${featureName} is shown as a visual UI preview in Phase 1. File processing, AI drafting, and document exports will be implemented in a later phase.`
    );
  };

  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-white to-slate-50 border-b border-slate-200 py-14 sm:py-18">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <p className="text-sm font-semibold text-[#1D4ED8]">
              AI CV Builder · Visual Interface Preview
            </p>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B1936] tracking-tight text-balance">
              Build structured, job-ready CVs and cover letters
            </h1>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              Preview the complete Skill2Career document workflow — from starting a CV from scratch
              or uploading an existing resume to selecting from 10 professional templates.
            </p>
          </div>

          {previewNotice && (
            <div
              role="status"
              className="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-4 flex items-start justify-between gap-4 text-sm text-[#0B1936]"
            >
              <div className="flex items-start gap-3">
                <Info className="h-5 w-5 text-[#1D4ED8] shrink-0 mt-0.5" aria-hidden="true" />
                <p>{previewNotice}</p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewNotice(null)}
                className="text-xs font-semibold text-[#1D4ED8] hover:underline shrink-0 cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Entry Workflows: Upload Existing CV & Create From Scratch */}
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 flex flex-col justify-between space-y-5">
              <div>
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8] mb-4">
                  <Upload className="h-5 w-5" aria-hidden="true" />
                </div>
                <h2 className="text-xl font-bold text-[#0B1936]">Upload Existing CV</h2>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Import a PDF or DOCX resume to parse sections, verify formatting clarity, and
                  spot missing metrics.
                </p>
              </div>

              <button
                type="button"
                onClick={() => triggerPhaseNotice('Upload Existing CV')}
                className="w-full rounded-xl border-2 border-dashed border-slate-300 hover:border-[#2563EB] bg-slate-50/70 p-6 text-center transition-colors cursor-pointer"
              >
                <p className="text-sm font-semibold text-[#0B1936]">
                  Drop PDF or DOCX file preview
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Visual preview only · No files uploaded in Phase 1
                </p>
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-7 flex flex-col justify-between space-y-5">
              <div>
                <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8] mb-4">
                  <FilePlus2 className="h-5 w-5" aria-hidden="true" />
                </div>
                <h2 className="text-xl font-bold text-[#0B1936]">Create CV From Scratch</h2>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  Follow a guided step-by-step editor covering career objective, education, project
                  outcomes, and core competencies.
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-2 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#0EA5E9]" aria-hidden="true" />
                  <span>Guided sections tailored for university students &amp; graduates</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[#0EA5E9]" aria-hidden="true" />
                  <span>Direct sync with Skill Assessment highlights (Phase 2)</span>
                </div>
              </div>

              <div>
                <Button onClick={() => triggerPhaseNotice('Create CV From Scratch')} size="md">
                  Preview Guided CV Editor
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 10 Professional CV Templates */}
      <section className="py-14 sm:py-18 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#1D4ED8] mb-2">
                <LayoutTemplate className="h-4 w-4" aria-hidden="true" />
                <span>10 Professional CV Templates</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0B1936]">
                Inspect ATS-friendly template layouts
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Select any template below to preview its miniature structural layout.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {cvTemplatesPreview.map((tpl, idx) => {
                const isSelected = tpl.id === selectedTemplate.id;
                return (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => setSelectedTemplateId(tpl.id)}
                    className={`text-left rounded-xl border p-4 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#1D4ED8] bg-blue-50/50 ring-1 ring-[#1D4ED8]'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 mb-1">
                      <span className="font-mono tabular-nums">
                        Template {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span>{tpl.style}</span>
                    </div>
                    <p className="text-sm font-bold text-[#0B1936]">{tpl.name}</p>
                    <p className="text-xs text-slate-600 mt-0.5">Best for: {tpl.bestFor}</p>
                  </button>
                );
              })}
            </div>

            {/* Live Miniature Structural Preview */}
            <div className="lg:col-span-5 bg-slate-50 rounded-2xl border border-slate-200 p-6 space-y-5 lg:sticky lg:top-24">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs text-slate-500">Selected Template Preview</p>
                  <h3 className="text-base font-bold text-[#0B1936]">{selectedTemplate.name}</h3>
                </div>
                <span className="text-xs font-medium text-[#1D4ED8]">
                  {selectedTemplate.style}
                </span>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4 min-h-[300px]">
                <div
                  className="pb-3 border-b-2"
                  style={{ borderColor: selectedTemplate.accentColor }}
                >
                  <p className="text-sm font-extrabold text-[#0B1936]">Aarav Perera (Sample)</p>
                  <p className="text-[11px] text-slate-500">
                    B.Sc. Business Analytics · Colombo · sample@university.edu
                  </p>
                </div>

                {selectedTemplate.layoutType === 'sidebar' ? (
                  <div className="grid grid-cols-12 gap-3 text-[11px]">
                    <div className="col-span-4 bg-slate-50 rounded-lg p-2.5 space-y-2">
                      <p className="font-bold text-[#0B1936]">Core Skills</p>
                      <p className="text-slate-600">MS Excel · Pivot Modeling · Reporting</p>
                      <p className="font-bold text-[#0B1936] pt-1">Education</p>
                      <p className="text-slate-600">B.Sc. Business Analytics</p>
                    </div>
                    <div className="col-span-8 space-y-2.5">
                      <div>
                        <p className="font-bold text-[#0B1936]">Career Objective</p>
                        <p className="text-slate-600 leading-relaxed">
                          Analytical graduate seeking junior business operations or reporting roles.
                        </p>
                      </div>
                      <div>
                        <p className="font-bold text-[#0B1936]">Academic Projects</p>
                        <p className="text-slate-600 leading-relaxed">
                          Built supply-chain variance dashboard tracking weekly fulfillment KPIs.
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 text-[11px]">
                    <div>
                      <p
                        className="font-bold mb-0.5"
                        style={{ color: selectedTemplate.accentColor }}
                      >
                        Career Objective
                      </p>
                      <p className="text-slate-600 leading-relaxed">
                        Detail-oriented Business Analytics graduate skilled in Excel modeling,
                        structured reporting, and cross-functional coordination.
                      </p>
                    </div>
                    <div>
                      <p
                        className="font-bold mb-0.5"
                        style={{ color: selectedTemplate.accentColor }}
                      >
                        Education &amp; Coursework
                      </p>
                      <p className="text-slate-600">
                        B.Sc. in Business Analytics · Quantitative Methods &amp; Operations
                      </p>
                    </div>
                    <div>
                      <p
                        className="font-bold mb-0.5"
                        style={{ color: selectedTemplate.accentColor }}
                      >
                        Verified Skills
                      </p>
                      <p className="text-slate-600">
                        MS Excel (XLOOKUP, Pivot Tables) · Analytical Reasoning · Stakeholder
                        Communication
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <span className="text-xs text-slate-500">Export Preview Formats:</span>
                <div className="flex items-center gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => triggerPhaseNotice('PDF Export')}
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>PDF Export</span>
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => triggerPhaseNotice('DOCX Export')}
                  >
                    <Download className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>DOCX Export</span>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI CV Improvement, Job Description Optimization & Cover Letter Generation Previews */}
      <section className="py-14 sm:py-18 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#0B1936]">
              Planned Optimization &amp; Export Capabilities
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-2">
              Static visual previews demonstrating upcoming Phase 2 document enhancement modules.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <article className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8]">
                <Wand2 className="h-5 w-5" aria-hidden="true" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1936]">AI CV Improvement</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Transform passive coursework descriptions into clear, action-oriented impact
                statements.
              </p>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 space-y-2 text-xs">
                <div>
                  <span className="font-semibold text-slate-500">Before (Sample):</span>
                  <p className="text-slate-600 mt-0.5">
                    &ldquo;Helped team make Excel sheets for monthly sales.&rdquo;
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-200">
                  <span className="font-semibold text-[#1D4ED8]">Improved Preview:</span>
                  <p className="text-[#0B1936] mt-0.5">
                    &ldquo;Automated monthly regional sales summaries in MS Excel using Pivot Tables
                    and XLOOKUP, reducing weekly reporting prep time.&rdquo;
                  </p>
                </div>
              </div>
            </article>

            <article className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8]">
                <Target className="h-5 w-5" aria-hidden="true" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1936]">Job Description Optimization</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Compare your CV sections against target vacancy keywords to ensure relevant skills
                are clearly represented.
              </p>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-600">Pivot Tables &amp; Reporting</span>
                  <span className="font-semibold text-emerald-700">Present</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Variance Analysis</span>
                  <span className="font-semibold text-emerald-700">Present</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Stakeholder Summaries</span>
                  <span className="font-semibold text-amber-700">Suggested Add</span>
                </div>
              </div>
            </article>

            <article className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8]">
                <MailCheck className="h-5 w-5" aria-hidden="true" />
              </div>
              <h3 className="text-lg font-bold text-[#0B1936]">Cover Letter Generation</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Pair every application with a concise, role-specific cover letter matching your CV
                tone and template.
              </p>
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-3.5 space-y-2 text-xs text-slate-600 leading-relaxed">
                <p className="font-semibold text-[#0B1936]">Sample Cover Letter Structure</p>
                <p>
                  Opening: Role alignment &amp; B.Sc. qualification · Body: Excel &amp; analytical
                  project evidence · Closing: Interview availability.
                </p>
              </div>
              <div>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => triggerPhaseNotice('Cover Letter Generation')}
                >
                  Preview Cover Letter Flow
                </Button>
              </div>
            </article>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
