import {
  UserPlus,
  ClipboardCheck,
  FileText,
  Briefcase,
  TrendingUp,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { MainLayout } from '../layouts/MainLayout';
import { Button } from '../components/Button';

const journeySteps = [
  {
    step: '01',
    title: 'Create Your Student or Graduate Profile',
    summary:
      'Start by entering your academic qualification, contact information, and target career direction.',
    details: [
      'Select your degree or diploma track so recommendations align with entry-level and graduate roles.',
      'Track profile completion with a transparent checklist in your student workspace.',
      'Future Phase 2: Persistent Supabase profiles with Google and LinkedIn single sign-on.'
    ],
    ctaLabel: 'Preview Registration',
    ctaTo: '/register',
    icon: UserPlus
  },
  {
    step: '02',
    title: 'Complete the 20-Minute Skill Assessment',
    summary:
      'Benchmark practical workplace readiness across spreadsheet proficiency, analytical judgment, and leadership.',
    details: [
      '20 structured questions totaling 20 marks in 20 minutes.',
      'Balanced weighting: MS Excel (60%), Situation Handling (20%), Analytical Skills (10%), Management Skills (10%).',
      'Generates an objective Career Score preview highlighting strong areas and targeted skill gaps.'
    ],
    ctaLabel: 'Explore Assessment Blueprint',
    ctaTo: '/assessment',
    icon: ClipboardCheck
  },
  {
    step: '03',
    title: 'Build & Refine Your Professional CV',
    summary:
      'Convert your academic projects and assessment strengths into clean, employer-ready application documents.',
    details: [
      'Choose from 10 ATS-friendly CV templates or upload an existing CV for structured improvement.',
      'Align bullet points with target job descriptions and prepare job-specific cover letters.',
      'Export finalized resumes in PDF or DOCX formats (enabled in upcoming build phases).'
    ],
    ctaLabel: 'Preview Resume Builder',
    ctaTo: '/resume-builder',
    icon: FileText
  },
  {
    step: '04',
    title: 'Explore Matched Career Opportunities & Keep Growing',
    summary:
      'Discover internships, management trainee openings, and entry-level roles while closing skill gaps.',
    details: [
      'Filter vacancies by Job Title, Company, Location, Category, Employment Type, and Experience.',
      'Review curated learning guides directly linked to lower-scoring assessment topics.',
      'Track application readiness from your centralized Student Dashboard.'
    ],
    ctaLabel: 'Browse Sample Jobs',
    ctaTo: '/jobs',
    icon: Briefcase
  }
];

export function HowItWorks() {
  return (
    <MainLayout>
      <section className="bg-gradient-to-b from-white to-slate-50 border-b border-slate-200 py-14 sm:py-18">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold text-[#1D4ED8] mb-2">How Skill2Career Works</p>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0B1936] tracking-tight text-balance">
              From university coursework to verified career readiness
            </h1>
            <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
              Skill2Career replaces guesswork with a structured four-stage workflow designed for
              university students and recent graduates.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button to="/dashboard" size="md">
                <span>Open Student Dashboard Preview</span>
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Button>
              <Button to="/register" variant="secondary" size="md">
                Get Started Free
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-14 sm:py-18 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          {journeySteps.map((item) => {
            const Icon = item.icon;
            return (
              <article
                key={item.step}
                className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start"
              >
                <div className="lg:col-span-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[#1D4ED8]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <span className="font-mono text-sm font-bold text-[#1D4ED8] tabular-nums">
                      Step {item.step}
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-[#0B1936]">{item.title}</h2>
                  <p className="text-sm text-slate-600 leading-relaxed">{item.summary}</p>
                </div>

                <div className="lg:col-span-5 space-y-3">
                  {item.details.map((detail) => (
                    <div key={detail} className="flex items-start gap-2.5 text-sm text-slate-700">
                      <CheckCircle2
                        className="h-4 w-4 text-[#0EA5E9] shrink-0 mt-0.5"
                        aria-hidden="true"
                      />
                      <span>{detail}</span>
                    </div>
                  ))}
                </div>

                <div className="lg:col-span-3 flex lg:justify-end items-center">
                  <Button to={item.ctaTo} variant="secondary" size="md">
                    <span>{item.ctaLabel}</span>
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <section className="py-14 sm:py-16 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl bg-[#0B1936] text-white p-8 sm:p-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="max-w-2xl space-y-2">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#38BDF8]">
                <TrendingUp className="h-4 w-4" aria-hidden="true" />
                <span>Continuous Feedback Loop</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Ready to inspect the full student experience?
              </h2>
              <p className="text-sm sm:text-base text-slate-300">
                Explore the Phase 1 demonstration dashboard, test the job filters, and review the
                20-question assessment blueprint.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 shrink-0">
              <Button to="/dashboard" size="lg">
                View Dashboard Demo
              </Button>
              <Button
                to="/jobs"
                variant="ghost"
                size="lg"
                className="text-white hover:bg-white/10 hover:text-white"
              >
                Explore Jobs
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
