import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Compass, Menu, X } from 'lucide-react';
import { Button } from './Button';

const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'How It Works', to: '/how-it-works' },
  { label: 'Skill Assessment', to: '/assessment' },
  { label: 'Resume Builder', to: '/resume-builder' },
  { label: 'Explore Jobs', to: '/jobs' }
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        <Link
          to="/"
          onClick={() => setMobileOpen(false)}
          className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-[#0B1936] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] rounded-md"
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#0B1936] via-[#1D4ED8] to-[#0EA5E9] text-white">
            <Compass className="h-4 w-4" aria-hidden="true" />
          </span>
          <span>Skill2Career</span>
        </Link>

        <nav
          aria-label="Main navigation"
          className="hidden lg:flex items-center gap-6 text-sm font-medium"
        >
          {navLinks.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                [
                  'whitespace-nowrap shrink-0 py-1 transition-colors duration-150 border-b-2',
                  isActive
                    ? 'text-[#1D4ED8] border-[#1D4ED8]'
                    : 'text-slate-600 border-transparent hover:text-[#0B1936] hover:border-slate-300'
                ].join(' ')
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-3 shrink-0">
          <Link
            to="/login"
            className="px-3.5 py-2 text-sm font-medium text-slate-700 hover:text-[#0B1936] whitespace-nowrap shrink-0 transition-colors"
          >
            Login
          </Link>
          <Button to="/register" size="sm">
            Get Started
          </Button>
        </div>

        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
          className="lg:hidden inline-flex items-center justify-center h-11 w-11 rounded-lg text-slate-700 hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2 shadow-lg">
          <nav aria-label="Mobile navigation" className="flex flex-col space-y-1">
            {navLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  [
                    'px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-blue-50 text-[#1D4ED8]'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-[#0B1936]'
                  ].join(' ')
                }
              >
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/dashboard"
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                [
                  'px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-blue-50 text-[#1D4ED8]'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-[#0B1936]'
                ].join(' ')
              }
            >
              Student Dashboard Preview
            </NavLink>
          </nav>

          <div className="pt-3 border-t border-slate-100 flex items-center gap-3">
            <Button
              to="/login"
              variant="secondary"
              size="md"
              className="flex-1"
              onClick={() => setMobileOpen(false)}
            >
              Login
            </Button>
            <Button
              to="/register"
              size="md"
              className="flex-1"
              onClick={() => setMobileOpen(false)}
            >
              Get Started
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
