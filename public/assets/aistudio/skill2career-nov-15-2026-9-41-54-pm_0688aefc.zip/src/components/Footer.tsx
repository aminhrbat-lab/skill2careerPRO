import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Compass, X, CheckCircle2 } from 'lucide-react';
import { Button } from './Button';

type ModalTopic = 'contact' | 'privacy' | 'terms' | null;

export function Footer() {
  const [activeModal, setActiveModal] = useState<ModalTopic>(null);
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });
  const [contactError, setContactError] = useState('');
  const [contactSent, setContactSent] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name.trim() || !contactForm.email.includes('@') || !contactForm.message.trim()) {
      setContactError('Please enter your name, a valid email address, and a short message.');
      return;
    }
    setContactError('');
    setContactSent(true);
  };

  const closeModal = () => {
    setActiveModal(null);
    setContactError('');
    setContactSent(false);
  };

  return (
    <footer className="bg-[#0B1936] text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          <div className="md:col-span-5 space-y-4">
            <Link to="/" className="inline-flex items-center gap-2.5 text-lg font-bold text-white">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#2563EB] to-[#0EA5E9] text-white">
                <Compass className="h-4 w-4" aria-hidden="true" />
              </span>
              <span>Skill2Career</span>
            </Link>
            <p className="text-sm text-slate-300 max-w-sm leading-relaxed">
              Learn Your Skills. Discover Your Potential. Build Your Career.
            </p>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Phase 1 Frontend Foundation — designed for university students and graduates preparing
              for modern analytical, operational, and management careers.
            </p>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h3 className="text-sm font-semibold text-white">Platform</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/how-it-works" className="hover:text-white transition-colors">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/assessment" className="hover:text-white transition-colors">
                  Skill Assessment
                </Link>
              </li>
              <li>
                <Link to="/resume-builder" className="hover:text-white transition-colors">
                  Resume Builder
                </Link>
              </li>
              <li>
                <Link to="/jobs" className="hover:text-white transition-colors">
                  Explore Jobs
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="hover:text-white transition-colors">
                  Student Dashboard Preview
                </Link>
              </li>
            </ul>
          </div>

          <div className="md:col-span-2 space-y-3">
            <h3 className="text-sm font-semibold text-white">Company</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/how-it-works" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveModal('contact')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Contact
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveModal('privacy')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveModal('terms')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Terms &amp; Conditions
                </button>
              </li>
            </ul>
          </div>

          <div className="md:col-span-2 space-y-3">
            <h3 className="text-sm font-semibold text-white">Connect</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="https://www.facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  Facebook
                </a>
              </li>
              <li>
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  LinkedIn
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-400">
          <p>&copy; {new Date().getFullYear()} Skill2Career. All rights reserved.</p>
          <p>Demonstration Preview Edition · No external data persistence active</p>
        </div>
      </div>

      {activeModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="footer-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs"
        >
          <div className="bg-white text-slate-900 rounded-xl border border-slate-200 max-w-lg w-full p-6 shadow-xl">
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <h2 id="footer-modal-title" className="text-lg font-bold text-[#0B1936]">
                {activeModal === 'contact' && 'Contact Skill2Career'}
                {activeModal === 'privacy' && 'Privacy Policy (Phase 1 Preview)'}
                {activeModal === 'terms' && 'Terms & Conditions (Phase 1 Preview)'}
              </h2>
              <button
                type="button"
                onClick={closeModal}
                aria-label="Close dialog"
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {activeModal === 'contact' && (
              <div className="pt-4">
                {contactSent ? (
                  <div className="py-6 text-center space-y-3">
                    <CheckCircle2 className="h-10 w-10 text-emerald-600 mx-auto" />
                    <p className="font-semibold text-[#0B1936]">Message Preview Validated</p>
                    <p className="text-sm text-slate-600">
                      Backend inquiry routing will be enabled in a future phase. Thank you for
                      previewing Skill2Career.
                    </p>
                    <Button onClick={closeModal} size="sm">
                      Close
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-4">
                    <p className="text-sm text-slate-600">
                      Have questions about university partnerships or upcoming Phase 2 releases? Send
                      a message preview below.
                    </p>
                    {contactError && (
                      <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                        {contactError}
                      </p>
                    )}
                    <div>
                      <label htmlFor="contact-name" className="block text-xs font-medium text-slate-700 mb-1">
                        Full Name
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        value={contactForm.name}
                        onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                        placeholder="Your name"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                      />
                    </div>
                    <div>
                      <label htmlFor="contact-email" className="block text-xs font-medium text-slate-700 mb-1">
                        Email Address
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        placeholder="you@university.edu"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                      />
                    </div>
                    <div>
                      <label htmlFor="contact-msg" className="block text-xs font-medium text-slate-700 mb-1">
                        Message
                      </label>
                      <textarea
                        id="contact-msg"
                        rows={3}
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        placeholder="How can we help?"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                      />
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button variant="secondary" size="sm" onClick={closeModal}>
                        Cancel
                      </Button>
                      <Button type="submit" size="sm">
                        Submit Preview
                      </Button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {activeModal === 'privacy' && (
              <div className="pt-4 space-y-3 text-sm text-slate-600 leading-relaxed">
                <p>
                  Skill2Career Phase 1 operates strictly as a frontend interface preview. No form
                  submissions, registration inputs, or assessment previews are transmitted to a
                  database or third-party service.
                </p>
                <p>
                  When authentication and data persistence are introduced in Phase 2, full privacy
                  controls and consent workflows will be published prior to user sign-up.
                </p>
                <div className="pt-2 flex justify-end">
                  <Button size="sm" onClick={closeModal}>
                    Understood
                  </Button>
                </div>
              </div>
            )}

            {activeModal === 'terms' && (
              <div className="pt-4 space-y-3 text-sm text-slate-600 leading-relaxed">
                <p>
                  All student scores, CV templates, learning modules, and vacancy listings displayed
                  in this Phase 1 release are demonstration previews designed to illustrate platform
                  structure and user workflows.
                </p>
                <p>
                  Sample job listings do not represent active open vacancies and no live application
                  processing takes place in this phase.
                </p>
                <div className="pt-2 flex justify-end">
                  <Button size="sm" onClick={closeModal}>
                    Close
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </footer>
  );
}
