import { AssessmentCategorySpec, CvTemplateSpec, StudentDashboardData } from '../types';

export const mockDashboardData: StudentDashboardData = {
  isDemonstration: true,
  student: {
    fullName: 'Aarav Perera',
    qualification: 'B.Sc. in Business Analytics (Final Year)',
    university: 'Demo University Profile',
    targetRole: 'Junior Business Data Analyst',
    location: 'Colombo · Open to Hybrid & Remote'
  },
  profileCompletion: {
    percentage: 78,
    checklist: [
      { id: 'p1', label: 'Academic qualification & degree details', completed: true },
      { id: 'p2', label: 'Target career track selected', completed: true },
      { id: 'p3', label: 'Baseline Skill Assessment preview reviewed', completed: true },
      { id: 'p4', label: 'Complete full 20-minute assessment (Phase 2)', completed: false },
      { id: 'p5', label: 'Export finalized PDF & DOCX CV (Phase 2)', completed: false }
    ]
  },
  careerScore: {
    overall: 74,
    max: 100,
    readinessLabel: 'Developing Career Readiness',
    summary:
      'Sample Career Score calculated from demonstration Excel proficiency, analytical reasoning, workplace judgement, and CV structure completeness.'
  },
  skillSummary: [
    {
      id: 'excel',
      name: 'MS Excel',
      score: 82,
      maxScore: 100,
      status: 'Strong',
      benchmarkNote: 'Strong command of lookup functions, Pivot Tables, and structured formulas.'
    },
    {
      id: 'situation',
      name: 'Situation Handling',
      score: 75,
      maxScore: 100,
      status: 'Strong',
      benchmarkNote: 'Balanced decision-making under deadline pressure and stakeholder conflict.'
    },
    {
      id: 'analytical',
      name: 'Analytical Skills',
      score: 70,
      maxScore: 100,
      status: 'Developing',
      benchmarkNote: 'Solid pattern recognition; room to sharpen multi-variable data interpretation.'
    },
    {
      id: 'management',
      name: 'Management Skills',
      score: 68,
      maxScore: 100,
      status: 'Needs Focus',
      benchmarkNote: 'Good task sequencing; practice delegation and milestone risk escalation.'
    }
  ],
  cvStatus: {
    percentage: 85,
    templateName: 'Meridian Executive Clean',
    lastUpdated: 'Demo Draft · Updated Nov 2026',
    sections: [
      {
        id: 'cv1',
        section: 'Career Objective & Summary',
        status: 'Complete',
        detail: 'Tailored toward entry-level business analytics roles'
      },
      {
        id: 'cv2',
        section: 'Academic Qualifications',
        status: 'Complete',
        detail: 'B.Sc. coursework and quantitative project highlights'
      },
      {
        id: 'cv3',
        section: 'Quantified Experience Bullets',
        status: 'In Progress',
        detail: 'Add measurable outcomes to internship bullet points'
      },
      {
        id: 'cv4',
        section: 'Job-Specific Cover Letter',
        status: 'Pending',
        detail: 'Available once AI Cover Letter Generator launches in Phase 2'
      }
    ]
  },
  recommendedJobIds: ['demo-job-1', 'demo-job-2', 'demo-job-7'],
  learningResources: [
    {
      id: 'lr1',
      title: 'Dynamic Lookup & Pivot Modeling Patterns',
      skillArea: 'MS Excel',
      duration: '35 min',
      format: 'Practice Sheet',
      level: 'Intermediate',
      description:
        'Master XLOOKUP, INDEX/MATCH, and multi-level Pivot Tables used in junior analyst case studies.',
      isDemonstration: true
    },
    {
      id: 'lr2',
      title: 'Structured Root-Cause & Variance Analysis',
      skillArea: 'Analytical Skills',
      duration: '25 min',
      format: 'Case Study',
      level: 'Beginner',
      description:
        'Learn how to isolate operational bottlenecks and explain metric shifts concisely to managers.',
      isDemonstration: true
    },
    {
      id: 'lr3',
      title: 'Priority Triage & Stakeholder Communication',
      skillArea: 'Management Skills',
      duration: '20 min',
      format: 'Interactive Guide',
      level: 'Beginner',
      description:
        'Practical frameworks for delegating tasks, managing conflicting deadlines, and escalating risks early.',
      isDemonstration: true
    }
  ],
  recentActivities: [
    {
      id: 'act1',
      action: 'Reviewed Skill Assessment Blueprint',
      detail: 'Inspected 20-question distribution across Excel, Analytical, Situation & Management.',
      timestamp: 'Today · 09:40 AM',
      category: 'Assessment'
    },
    {
      id: 'act2',
      action: 'Selected CV Template Preview',
      detail: 'Previewed "Meridian Executive Clean" layout for Analyst applications.',
      timestamp: 'Yesterday · 04:15 PM',
      category: 'CV Builder'
    },
    {
      id: 'act3',
      action: 'Bookmarked 2 Sample Vacancies',
      detail: 'Junior Business Data Analyst & Management Trainee (Demo listings).',
      timestamp: 'Nov 13 · 11:20 AM',
      category: 'Jobs'
    },
    {
      id: 'act4',
      action: 'Updated Demo Academic Profile',
      detail: 'Added B.Sc. in Business Analytics qualification details.',
      timestamp: 'Nov 12 · 02:05 PM',
      category: 'Profile'
    }
  ]
};

export const assessmentBreakdown: AssessmentCategorySpec[] = [
  {
    id: 'excel',
    name: 'MS Excel',
    questions: 12,
    percentage: 60,
    marks: 12,
    focusTopics: [
      'Lookup & reference formulas (XLOOKUP, VLOOKUP, INDEX/MATCH)',
      'Conditional aggregation (SUMIFS, COUNTIFS, IF/IFS logic)',
      'Pivot Tables, data cleaning, and formatting rules',
      'Chart selection and basic error-handling formulas'
    ],
    sampleContext:
      'Tests practical spreadsheet fluency required on day one in business, finance, and operations roles.'
  },
  {
    id: 'situation',
    name: 'Situation Handling',
    questions: 4,
    percentage: 20,
    marks: 4,
    focusTopics: [
      'Resolving conflicting team deadlines calmly',
      'Handling unclear stakeholder instructions',
      'Responding constructively to client or peer feedback',
      'Ethical judgment and professional accountability'
    ],
    sampleContext:
      'Scenario-based multiple choice evaluating workplace maturity and pragmatic judgment.'
  },
  {
    id: 'analytical',
    name: 'Analytical Skills',
    questions: 2,
    percentage: 10,
    marks: 2,
    focusTopics: [
      'Interpreting multi-column trend tables',
      'Spotting logical inconsistencies and root causes',
      'Quantitative comparison and ratio reasoning'
    ],
    sampleContext:
      'Measures structured problem breakdown and evidence-based conclusions.'
  },
  {
    id: 'management',
    name: 'Management Skills',
    questions: 2,
    percentage: 10,
    marks: 2,
    focusTopics: [
      'Task prioritization and resource allocation',
      'Cross-team coordination and milestone tracking',
      'Delegation clarity and risk mitigation'
    ],
    sampleContext:
      'Evaluates foundational leadership readiness for trainee and coordinator tracks.'
  }
];

export const cvTemplatesPreview: CvTemplateSpec[] = [
  {
    id: 'tpl-1',
    name: 'Meridian Executive Clean',
    style: 'Single-Column Editorial',
    bestFor: 'Business Analysts & Finance',
    accentColor: '#1D4ED8',
    layoutType: 'classic'
  },
  {
    id: 'tpl-2',
    name: 'Nordic Slate Sidebar',
    style: 'Two-Column Structured',
    bestFor: 'Operations & Project Coordinators',
    accentColor: '#0B1936',
    layoutType: 'sidebar'
  },
  {
    id: 'tpl-3',
    name: 'Harbor Graduate Standard',
    style: 'ATS-First Minimal',
    bestFor: 'University Fresh Graduates',
    accentColor: '#0EA5E9',
    layoutType: 'compact'
  },
  {
    id: 'tpl-4',
    name: 'Crestline Management Track',
    style: 'Leadership Header',
    bestFor: 'Management Trainees',
    accentColor: '#1E3A8A',
    layoutType: 'executive'
  },
  {
    id: 'tpl-5',
    name: 'Solstice Modern Grid',
    style: 'Balanced Split Header',
    bestFor: 'Marketing & Growth Roles',
    accentColor: '#4F46E5',
    layoutType: 'modern'
  },
  {
    id: 'tpl-6',
    name: 'Beacon Technical Brief',
    style: 'Skills-First Compact',
    bestFor: 'Data & IT Support Roles',
    accentColor: '#0284C7',
    layoutType: 'compact'
  },
  {
    id: 'tpl-7',
    name: 'Veridian Advisory Classic',
    style: 'Traditional Corporate',
    bestFor: 'Consulting & Accounting',
    accentColor: '#0F172A',
    layoutType: 'classic'
  },
  {
    id: 'tpl-8',
    name: 'Atlas Crisp Two-Tone',
    style: 'Accent Rail Layout',
    bestFor: 'Supply Chain & Logistics',
    accentColor: '#2563EB',
    layoutType: 'sidebar'
  },
  {
    id: 'tpl-9',
    name: 'Horizon Intern Starter',
    style: 'Coursework & Projects Focus',
    bestFor: 'Undergraduate Internships',
    accentColor: '#0EA5E9',
    layoutType: 'modern'
  },
  {
    id: 'tpl-10',
    name: 'Summit Senior Graduate',
    style: 'Impact Metrics Layout',
    bestFor: 'Competitive Graduate Programs',
    accentColor: '#4338CA',
    layoutType: 'executive'
  }
];
