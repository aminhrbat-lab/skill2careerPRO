export type EmploymentType = 'Full-Time' | 'Part-Time' | 'Internship' | 'Graduate Trainee';

export type ExperienceLevel = 'Entry Level' | '0–1 Years' | '1–2 Years' | 'Student / Intern';

export type JobCategory =
  | 'Data & Analytics'
  | 'Business Operations'
  | 'Finance & Accounting'
  | 'Management Trainee'
  | 'Marketing & Growth'
  | 'Human Resources';

export interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  category: JobCategory;
  employmentType: EmploymentType;
  experience: ExperienceLevel;
  deadline: string;
  salaryRange: string;
  summary: string;
  responsibilities: string[];
  requiredSkills: string[];
  isDemonstration: true;
}

export interface SkillMetric {
  id: string;
  name: string;
  score: number;
  maxScore: number;
  status: 'Strong' | 'Developing' | 'Needs Focus';
  benchmarkNote: string;
}

export interface ProfileChecklistItem {
  id: string;
  label: string;
  completed: boolean;
}

export interface CvSectionItem {
  id: string;
  section: string;
  status: 'Complete' | 'In Progress' | 'Pending';
  detail: string;
}

export interface LearningResource {
  id: string;
  title: string;
  skillArea: string;
  duration: string;
  format: 'Interactive Guide' | 'Practice Sheet' | 'Case Study';
  level: 'Beginner' | 'Intermediate';
  description: string;
  isDemonstration: true;
}

export interface ActivityItem {
  id: string;
  action: string;
  detail: string;
  timestamp: string;
  category: 'Assessment' | 'CV Builder' | 'Profile' | 'Jobs';
}

export interface StudentDashboardData {
  isDemonstration: true;
  student: {
    fullName: string;
    qualification: string;
    university: string;
    targetRole: string;
    location: string;
  };
  profileCompletion: {
    percentage: number;
    checklist: ProfileChecklistItem[];
  };
  careerScore: {
    overall: number;
    max: number;
    readinessLabel: string;
    summary: string;
  };
  skillSummary: SkillMetric[];
  cvStatus: {
    percentage: number;
    templateName: string;
    lastUpdated: string;
    sections: CvSectionItem[];
  };
  recommendedJobIds: string[];
  learningResources: LearningResource[];
  recentActivities: ActivityItem[];
}

export interface AssessmentCategorySpec {
  id: string;
  name: string;
  questions: number;
  percentage: number;
  marks: number;
  focusTopics: string[];
  sampleContext: string;
}

export interface CvTemplateSpec {
  id: string;
  name: string;
  style: string;
  bestFor: string;
  accentColor: string;
  layoutType: 'classic' | 'sidebar' | 'executive' | 'compact' | 'modern';
}
